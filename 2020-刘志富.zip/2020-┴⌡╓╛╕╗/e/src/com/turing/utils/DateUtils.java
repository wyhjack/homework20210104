package com.turing.utils;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

/**
 * @desc 日期工具类：实现求两个日期相差的天数
 * @author 86186
 *
 */
public class DateUtils {
	public static int differentDaysByMillisecond(String dateStr,String dateStr2) throws ParseException
	{
		//1.初始化格式化工具类
		SimpleDateFormat format=new SimpleDateFormat("yyyy-MM-dd");
		//2.将字符串类型的日期转变为日期类型
		 Date fDate = format.parse(dateStr);
		 Date oDate = format.parse(dateStr2);
		//3.初始化日历工具类
		Calendar aCalendar = Calendar.getInstance();
		//4.根据日历工具类对象将上面获取到的两个日期转变为天
		aCalendar.setTime(fDate);
		int day1 = aCalendar.get(Calendar.DAY_OF_YEAR);
		
		//5.重复第4步
		aCalendar.setTime(oDate);
		int day2 =aCalendar.get(Calendar.DAY_OF_YEAR);
		
		
		return day2-day1;
	}
}
