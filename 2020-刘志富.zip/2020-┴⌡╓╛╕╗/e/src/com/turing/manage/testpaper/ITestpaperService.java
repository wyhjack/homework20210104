package com.turing.manage.testpaper;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;

/**
 * @desc 试卷管理M层的接口
 * @author 86186
 *
 */
public interface ITestpaperService {

	List<Map<String, Object>> queryTestpaper() throws ClassNotFoundException, SQLException;

	List<Map<String, Object>> queryClasss() throws ClassNotFoundException, SQLException;

	List<Map<String, Object>> queryCourse() throws ClassNotFoundException, SQLException;

	void save(String testpaper_name, String testpaper_radio_num, String testpaper_check_num, String testpaper_time_use,
			String classs_id, String course_id) throws ClassNotFoundException, FileNotFoundException, SQLException, IOException;

	void createTestPaperById(String id) throws ClassNotFoundException, SQLException, FileNotFoundException, IOException;

	Map<String, Object> queryTestPaperById(String id) throws ClassNotFoundException, SQLException;

	List<Map<String, Object>> queryTestPaperRadioInfo(String id) throws ClassNotFoundException, SQLException;

	List<Map<String, Object>> queryTestPaperCheckInfo(String id) throws ClassNotFoundException, SQLException;

	void updateByCanTest(String id) throws ClassNotFoundException, FileNotFoundException, SQLException, IOException;

	void updateByFinishTest(String id) throws ClassNotFoundException, FileNotFoundException, SQLException, IOException;

}
