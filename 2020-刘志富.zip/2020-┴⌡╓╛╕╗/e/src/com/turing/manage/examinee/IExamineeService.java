package com.turing.manage.examinee;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;

public interface IExamineeService {

	List<Map<String, Object>> queryToExaminee(String classs_id, String key) throws ClassNotFoundException, SQLException;

	List<Map<String, Object>> queryToClasss() throws ClassNotFoundException, SQLException;

	void delete(String[] strings) throws ClassNotFoundException, FileNotFoundException, SQLException, IOException;
	
	public void saveByImportExcel(List<String> columnValuesList) throws ClassNotFoundException, SQLException, FileNotFoundException, IOException;

}
