package com.turing.manage.examinee;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.SQLException;
import java.sql.Types;
import java.util.List;
import java.util.Map;

import com.turing.dao.Dao;
import com.turing.dao.DaoImpl;

public class ExamineeServiceImpl implements IExamineeService {
	// 创建Dao工具类获取数据
	Dao dao = new DaoImpl();

	@Override
	public List<Map<String, Object>> queryToExaminee(String classs_id, String key)
			throws ClassNotFoundException, SQLException {
		// 如果为空则全查询为%%
		classs_id = "%" + classs_id + "%";
		key = "%" + key + "%";
		// 加上去除空格用户体验更佳
		key = key.replaceAll(" ", "");
		return dao.executeQueryForList("select * from examinee where classs_id like ? and examinee_name like ?",
				new int[] { Types.VARCHAR, Types.VARCHAR }, new Object[] { classs_id, key });
	}

	@Override
	public List<Map<String, Object>> queryToClasss() throws ClassNotFoundException, SQLException {
		return dao.executeQueryForList("select * from classs");
	}

	@Override
	public void delete(String[] strings)
			throws ClassNotFoundException, FileNotFoundException, SQLException, IOException {

		for (int i = 0; i < strings.length; i++) {
			dao.executeUpdate(" delete from grade where examinee_id = ? ", new int[] { Types.VARCHAR },
					new Object[] { strings[i] });
			dao.executeUpdate(" delete from examinee where examinee_id = ? ", new int[] { Types.VARCHAR },
					new Object[] { strings[i] });
		}

	}

	@Override
	public void saveByImportExcel(List<String> columnValuesList)
			throws ClassNotFoundException, SQLException, FileNotFoundException, IOException {

		List<Map<String, Object>> list_examinee_ids = dao.executeQueryForList(
				"select * from examinee where examinee_id=?", new int[] { Types.VARCHAR },
				new Object[] { columnValuesList.get(0) });
		if (list_examinee_ids.size() <= 0) {
			String sql = "  insert into examinee values(?,?,?,?,?,?,?,?,?,?)  ";
			int[] types = new int[10];
			Object[] values = new Object[10];
			types[0] = Types.VARCHAR;
			types[1] = Types.VARCHAR;
			types[2] = Types.VARCHAR;
			types[3] = Types.VARCHAR;
			types[4] = Types.VARCHAR;
			types[5] = Types.VARCHAR;
			types[6] = Types.VARCHAR;
			types[7] = Types.VARCHAR;
			types[8] = Types.VARCHAR;
			types[9] = Types.VARCHAR;

			values[0] = columnValuesList.get(0);
			values[1] = columnValuesList.get(1);
			values[2] = columnValuesList.get(2);
			values[3] = columnValuesList.get(3);
			values[4] = columnValuesList.get(4);
			values[5] = columnValuesList.get(5);
			values[6] = columnValuesList.get(6);
			values[7] = columnValuesList.get(7);
			values[8] = columnValuesList.get(8);
			values[9] = columnValuesList.get(9);

			dao.executeUpdate(sql, types, values);
		}

	}
}
