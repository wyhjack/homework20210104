package com.turing.manage.examinee;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.OutputStream;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.turing.utils.ExcelUtils;

public class ExamineeServlet extends HttpServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	// 创建功能类M层
	IExamineeService examineeService = new ExamineeServiceImpl();
	// 创建导出的工具类
	ExcelUtils excel = new ExcelUtils();

	@Override
	protected void service(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// 获取传进来的方法
		String method = request.getParameter("method");
		try {
			if (method.equals("query")) {
				this.query(request, response);
			} else if (method.equals("delete")) {
				this.delete(request, response);
			} else if (method.equals("exportExcel")) {
				this.exportExcel(request, response);
			} else if (method.equals("importExcel")) {
				this.importExcel(request, response);
			}
		} catch (ClassNotFoundException e) {
			System.out.println("该类不存在");
		} catch (SQLException e) {
			System.out.println("SQL语句异常");
		}
	}

	/**
	 * @desc 导入excel表
	 * @param request
	 * @param response
	 * @throws IOException
	 * @throws SQLException
	 * @throws ClassNotFoundException
	 */
	private void importExcel(HttpServletRequest request, HttpServletResponse response)
			throws IOException, ClassNotFoundException, SQLException {
		long time = System.currentTimeMillis();
		// 总的数据
		List<List<String>> allList = new ArrayList<List<String>>();
		// 一系列空为了分别对应不同的excel文件
		Workbook wb = null;// 备注：导入的包一定都是ss下的
		Sheet sheet;
		Row row;
		String fed = request.getParameter("fed");
		System.out.println("fed:" + fed);
		File excel = new File(fed);
		FileInputStream fileInputStream = new FileInputStream(excel);
		if (excel.isFile() && excel.exists()) {
			// 获取当前文件的名字
			String excelName = excel.getName();
			// 截取后缀开始的前一位
			int st = excelName.lastIndexOf(".");
			System.out.println(st);
			// 截取文件的后缀
			String suffix = (String) excelName.subSequence(st + 1, excelName.length());
			System.out.println(suffix);
			if (suffix.equals("xlsx")) {
				System.out.println("2007解析.");
				wb = new XSSFWorkbook(fileInputStream);
			} else if (suffix.equals("xls")) {
				System.out.println("2003解析");
				wb = new HSSFWorkbook(fileInputStream);
			} else {
				System.out.println("文件类型错误!");
				System.exit(0);// 退出当前程序
			}

		}

		sheet = wb.getSheetAt(0);
		// 获取当前sheet中有多少个行
		int totalRowNums = sheet.getPhysicalNumberOfRows();

		for (int i = 1; i < totalRowNums; i++) {
			row = sheet.getRow(i);// 取出每一行
			int totalCellNums = row.getPhysicalNumberOfCells();// 获取一共有多少列
			List<String> columnValuesList = new ArrayList<String>();
			for (int k = 0; k < totalCellNums; k++) {
				Cell cell = row.getCell(k);
				String cellValue = ExcelUtils.getFormatValue(cell);
				System.out.print(cellValue + "\t");
				columnValuesList.add(k, cellValue);
			}
			new Thread(()->{
				try {
					examineeService.saveByImportExcel(columnValuesList);
				} catch (ClassNotFoundException | SQLException | IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
            }).start();
			
			System.out.println("开始读取新的一行数据");
		}
		System.out.println("耗时：" + (long) (System.currentTimeMillis() - time));
		// 3.重定向
		response.sendRedirect(request.getContextPath() + "/manage/examinee.do?method=query");

	}

	/**
	 * @desc 导出excel表格
	 * @param request
	 * @param response
	 * @throws SQLException
	 * @throws ClassNotFoundException
	 * @throws IOException
	 */
	private void exportExcel(HttpServletRequest request, HttpServletResponse response)
			throws ClassNotFoundException, SQLException, IOException {
		// 设置文件导出的名字
		String fileName = "考生信息.xls";
		// 修改文件的配置,导出格式文件等
		excel.setting(request, response, fileName);
		// 获取需要查询的值
		String classs_id = request.getParameter("classsID");
		String key = request.getParameter("key");
		// 把null换成空,模糊查询所有
		if (classs_id == null) {
			classs_id = "";
		}
		if (key == null) {
			key = "";
		}
		System.out.println(classs_id);
		System.out.println(key);
		// 使用M层获取数据
		List<Map<String, Object>> list = examineeService.queryToExaminee(classs_id, key);
		System.out.println(list.get(0));
		// 创建出暂时承载数据的excel表
		HSSFWorkbook workbook = new HSSFWorkbook();
		String sheetName = "考生信息";
		HSSFSheet sheet = workbook.createSheet(sheetName);

		// 设置表头数据,以及需要获取的数据名称
		String[] tableTop = { "考生编号", "班级编号", "考生姓名", "登陆密码", "性别", "提问", "答案", "专业", "身份证号", "日期" };
		String[] columnName = { "examinee_id", "classs_id", "examinee_name", "examinee_pass", "examinee_sex",
				"examinee_question", "examinee_answer", "examinee_specialty", "examinee_identity", "examinee_time" };
		// 创建表头(第一行)
		HSSFRow topRow = sheet.createRow(0);
		// for循环加入表头
		for (int i = 0; i < tableTop.length; i++) {
			// 把数据添加进入
			topRow.createCell(i).setCellValue(tableTop[i]);
		}
		// 添加完表头后,从第二行开始加入考生数据
		for (int i = 0; i < list.size(); i++) {
			// 从第二行开始添加数据
			HSSFRow row = sheet.createRow(i + 1);
			// 获取每一行的考生
			Map<String, Object> map = list.get(i);
			for (int j = 0; j < columnName.length; j++) {
				row.createCell(j).setCellValue((String) map.get(columnName[j]));
			}
		}
		// 数据格式化
		excel.setColumnAutoAdapter(sheet, list.size());
		// 把数据写入之后关闭
		OutputStream out = response.getOutputStream();
		workbook.write(out);
		out.close();

	}

	/**
	 * @desc 删除所选的数据
	 * @param request
	 * @param response
	 * @throws ClassNotFoundException
	 * @throws FileNotFoundException
	 * @throws SQLException
	 * @throws IOException
	 */
	private void delete(HttpServletRequest request, HttpServletResponse response)
			throws ClassNotFoundException, FileNotFoundException, SQLException, IOException {
		// 获取表单中提交的所有数据,本质为储存了众多班级ID的信息数组,
		String[] strings = request.getParameterValues("delIdArray");
		// 检测数据
		for (String string : strings) {
			System.out.println(string);
		}
		// 应对所有班级ID进行删除
		examineeService.delete(strings);

		// 删除完毕,刷新界面
		response.sendRedirect(request.getContextPath() + "/manage/examinee.do?method=query");
	}

	/**
	 * @desc 获取所有的数据
	 * @param request
	 * @param response
	 * @throws SQLException
	 * @throws ClassNotFoundException
	 * @throws IOException
	 * @throws ServletException
	 */
	private void query(HttpServletRequest request, HttpServletResponse response)
			throws ClassNotFoundException, SQLException, ServletException, IOException {
		System.out.println("进入了学生管理C层的query方法");
		// 获取需要查询的班级ID
		String classs_id = request.getParameter("classs_id");
		System.out.println("classs_id---->" + classs_id);
		// 获取需要查询的人名
		String key = request.getParameter("key");
		// 避免空指针所以得把null换成空
		if (classs_id == null) {
			classs_id = "";
		}
		if (key == null) {
			key = "";
		}

		// 获取examinee的全部数据
		List<Map<String, Object>> examineeList = examineeService.queryToExaminee(classs_id, key);
		// 获取classs的全部数据
		List<Map<String, Object>> classsList = examineeService.queryToClasss();
		// 存入数据
		request.setAttribute("examineeList", examineeList);
		request.setAttribute("classsList", classsList);
		request.setAttribute("classs_id", classs_id);
		request.setAttribute("key", key);
		// 转向至展示界面
		request.getRequestDispatcher("/manage/examinee/list.jsp").forward(request, response);
	}

}
