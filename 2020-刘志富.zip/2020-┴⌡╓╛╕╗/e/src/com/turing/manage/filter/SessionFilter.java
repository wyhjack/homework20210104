package com.turing.manage.filter;

import java.io.IOException;

import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


/**
 * @desc URl过滤器:用于过滤掉没有登录成功的用户
 * @author 86186
 *
 */
public class SessionFilter implements javax.servlet.Filter{

	@Override
	public void destroy() {
		System.out.println("过滤器销毁,与Servlet.destroy()一样");
	}

	@Override
	public void doFilter(ServletRequest arg0, ServletResponse arg1, FilterChain arg2)
			throws IOException, ServletException {
		System.out.println("过滤器开始工作,类似于Servlet.service()");
		// 1.向下转型,获取request和response
		HttpServletRequest request= (HttpServletRequest)arg0;
		HttpServletResponse response = (HttpServletResponse)arg1;
		 
		// 2.设置特权放行页面
		String path = request.getServletPath();
		System.out.println("path--->" + path);
		if ((path.equals("/manage/login.jsp"))||(path.equals("/manage/login.do"))) {
			System.out.println("为特权页面,放行");
			arg2.doFilter(request, response);
			return;
		}
		// 3.session的过滤
		HttpSession session = request.getSession();
		if (session.getAttribute("user")==null) {
			System.out.println("session为空,您还没有登录");
			String errorMsg = "您还没有登录,不能访问本界面!";
			request.setAttribute("error", errorMsg);
			request.getRequestDispatcher("/manage/error.jsp").forward(request, response);
			return;
		} else {
			System.out.println("过滤通过");
			arg2.doFilter(request, response);
			return;
		}
	}

	@Override
	public void init(FilterConfig arg0) throws ServletException {
		System.out.println("过滤器初始化,与Servlet.init()一样");
	}

	

}
