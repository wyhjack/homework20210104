package com.turing.manage.listeners;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpSessionEvent;
import javax.servlet.http.HttpSessionListener;

/**
 * @desc 通过sessionListener实现统计在线人数
 * @author 86186
 *
 */
public class SessionListener implements HttpSessionListener {
	/**
	 * @desc session创建时会自动使用的方法
	 */
	@Override
	public void sessionCreated(HttpSessionEvent sessionEvent) {
		System.out.println("Session创建时会自动调用的方法");
		// 如若获取在线人数,需要判断连接的session然后存储至一个全局容器中,可供全局使用和检查,如application对象
		// 获取application对象
		ServletContext servletContext = sessionEvent.getSession().getServletContext();
		// 判断当前是否有用户在线
		Integer numSession = (Integer) servletContext.getAttribute("numSession");
		if (numSession == null) { // 如果没人的话,那么就设置为1
			numSession = 1;
		} else { // 如果有人的话,那就加1
			int num = numSession.intValue();
			numSession = 1 + num;
		}
		// 存入全局容器
		servletContext.setAttribute("numSession", numSession);
	}

	/**
	 * @desc session销毁时会自动使用的方法
	 */
	@Override
	public void sessionDestroyed(HttpSessionEvent sessionEvent) {
		System.out.println("Session销毁时会自动调用的方法");
		// 获取application对象
		ServletContext servletContext = sessionEvent.getSession().getServletContext();
		// 判断当前是否有用户在线
		Integer numSession = (Integer) servletContext.getAttribute("numSession");
		if (numSession == null) { // 如果没人的话,那么就设置为0
			numSession = 0;
		} else { // 如果有人的话,那就-2
			int num = numSession.intValue();
			numSession = num - 2;
		}
		// 存入全局容器
		servletContext.setAttribute("numSession", numSession);
	}

}
