package com.turing.manage.listeners;

import javax.servlet.ServletRequest;
import javax.servlet.ServletRequestEvent;
import javax.servlet.ServletRequestListener;

/**
 * @desc 通过ServletRequestListener实现对ip的监听
 * @author 86186
 *
 */
public class MyServletRequestListener implements ServletRequestListener {

	@Override
	public void requestDestroyed(ServletRequestEvent requestEvent) {
		System.out.println("requestDestroyed为开启请求自动调用的方法");
		// 获取发起请求的IP
		ServletRequest servletRequest = requestEvent.getServletRequest();
		System.out.println("remoteIp:" + servletRequest.getRemoteAddr());
	}

	@Override
	public void requestInitialized(ServletRequestEvent requestEvent) {
		System.out.println("requestDestroyed为结束请求自动调用的方法");
		// 获取结束请求的IP
		ServletRequest servletRequest = requestEvent.getServletRequest();
		System.out.println("remoteIp:" + servletRequest.getRemoteAddr());
	}

}
