package com.turing.manage.listeners;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
/**
 * @desc servletContextListener监听器实现预加载一些数据
 * @author 86186
 *
 */
public class MyLiceneseListener implements ServletContextListener{

	@Override
	public void contextDestroyed(ServletContextEvent arg0) {
		System.out.println("开启tomcat时自动调用的方法");
		// 此方法可以预先加载一系列可复用的对象
	}

	@Override
	public void contextInitialized(ServletContextEvent arg0) {
		System.out.println("关闭tomcat时自动调用的方法");
	}
	
}
