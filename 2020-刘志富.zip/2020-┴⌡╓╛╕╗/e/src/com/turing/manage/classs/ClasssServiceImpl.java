package com.turing.manage.classs;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.SQLException;
import java.sql.Types;
import java.util.List;
import java.util.Map;

import org.apache.tomcat.util.buf.StringCache;

import com.turing.dao.Dao;
import com.turing.dao.DaoImpl;

/**
 * @desc 班级管理的M层
 * @author 86186
 *
 */
public class ClasssServiceImpl implements IClasssService {
	// 创建Dao工具类
	Dao dao = new DaoImpl();

	@Override
	public List<Map<String, Object>> queryAll() throws ClassNotFoundException, SQLException {
		return dao.executeQueryForList("select * from classs;");
	}

	@Override
	public void addPage(String classs_id, String classs_name, String classs_time)
			throws ClassNotFoundException, FileNotFoundException, SQLException, IOException {
		dao.executeUpdate(" insert into classs values (?,?,?)",
				new int[] { Types.VARCHAR, Types.VARCHAR, Types.VARCHAR },
				new Object[] { classs_id, classs_name, classs_time });
	}

	@Override
	public void delete(String[] strings)
			throws ClassNotFoundException, FileNotFoundException, SQLException, IOException {
		// for循环
		for (String classs_id : strings) {
			// 此表关联多个表,得按照步骤删除
			// 1.删除成绩表中学生的成绩
			String sql1 = " delete from grade where  examinee_id  in ( select examinee_id from examinee where  classs_id=? ) ";
			// 2.删除对应班级的考生信息
			String sql2 = "  delete from examinee where classs_id=?  ";
			// 3.删除对应班级的试卷
			String sql3 = " delete from   testpaper_list  where testpaper_id in  ( select testpaper_id from testpaper where classs_id=?  ) ";
			// 4.删除试卷的详细信息
			String sql4 = " delete from testpaper where classs_id=? ";
			// 5.删除班级信息
			String sql5 = " delete from classs where classs_id=?   ";

			dao.executeUpdate(sql1, new int[] { Types.VARCHAR }, new Object[] { classs_id });
			dao.executeUpdate(sql2, new int[] { Types.VARCHAR }, new Object[] { classs_id });
			dao.executeUpdate(sql3, new int[] { Types.VARCHAR }, new Object[] { classs_id });
			dao.executeUpdate(sql4, new int[] { Types.VARCHAR }, new Object[] { classs_id });
			dao.executeUpdate(sql5, new int[] { Types.VARCHAR }, new Object[] { classs_id });
		}
	}

	@Override
	public Map<String, Object> queryOneByUserID(String classs_id) throws ClassNotFoundException, SQLException {
		return dao.executeQueryForMap("select * from classs where classs_id = '"+ classs_id+"'");
	}
	@Override
	public void editPage(String classs_id,String classs_name) throws ClassNotFoundException, SQLException {
		dao.executeUpdate(
				"update classs set classs_name='" + classs_name +  "' where classs_id='" + classs_id + "'");
	}
}
