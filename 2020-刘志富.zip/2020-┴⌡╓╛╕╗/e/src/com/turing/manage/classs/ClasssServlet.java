package com.turing.manage.classs;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * @desc 班级管理的C层
 * @author 86186
 *
 */
public class ClasssServlet extends HttpServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	IClasssService classsService = new ClasssServiceImpl();

	@Override
	protected void service(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// 获取判断
		String method = request.getParameter("method");

		try {
			if (method.equals("query")) {
				this.query(request, response);
			} else if (method.equals("add")) {
				this.add(request,response);
			} else if (method.equals("addPage")) {
				this.addPage(request,response);
			} else if (method.equals("delete")) {
				this.delete(request,response);
			} else if (method.equals("edit")) {
				this.edit(request,response);
			} else if (method.equals("editPage")) {
				this.editPage(request,response);
			}
		} catch (ClassNotFoundException e) {
			System.out.println("没有找到该类");
		} catch (SQLException e) {
			System.out.println("SQL语句异常");
		}
	}
	/**
	 * @desc 保存更新数据
	 * @param request
	 * @param response
	 * @throws SQLException 
	 * @throws ClassNotFoundException 
	 * @throws IOException 
	 */
	private void editPage(HttpServletRequest request, HttpServletResponse response) throws ClassNotFoundException, SQLException, IOException {
		// 获取修改后的值,可在此用js判断是否修改,从而减少服务器使用
		String classs_name = request.getParameter("name");
		String classs_id = request.getParameter("classs_id");
		// 使用M层修改
		classsService.editPage(classs_id,classs_name);
		System.out.println("更新完毕");
		// 回跳刷新
		response.sendRedirect(request.getContextPath()+ "/classs.do?method=query");
	}
	/**
	 * @desc 进入更新方法
	 * @param request
	 * @param response
	 * @throws IOException 
	 * @throws ServletException 
	 * @throws SQLException 
	 * @throws ClassNotFoundException 
	 */
	private void edit(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException, ClassNotFoundException, SQLException {
		System.out.println("进入ClasssServlet--->add()转跳界面");
		// 获取当前数值
		// 获取被更新ID
		String classs_id = request.getParameter("classs_id");
		// 获取被修改的数据
		Map<String, Object> map = classsService.queryOneByUserID(classs_id);
		// 存入被修改数据
		request.setAttribute("map", map);
		request.getRequestDispatcher("manage/classs/edit.jsp").forward(request, response);
		
		System.out.println("跳转成功");
	}
	/**
	 * @desc 删除方法
	 * @param request
	 * @param response
	 * @throws IOException 
	 * @throws SQLException 
	 * @throws FileNotFoundException 
	 * @throws ClassNotFoundException 
	 */
	private void delete(HttpServletRequest request, HttpServletResponse response) throws ClassNotFoundException, FileNotFoundException, SQLException, IOException {
		// 获取表单中提交的所有数据,本质为储存了众多班级ID的信息数组,
		String[] strings = request.getParameterValues("delIdArray");
		// 检测数据
//		for (String string : strings) {
//			System.out.println(string);
//		}
		// 应对所有班级ID进行删除
		classsService.delete(strings);
		
		// 删除完毕,刷新界面
		response.sendRedirect(request.getContextPath()+ "/classs.do?method=query");
	}
	/**
	 * @desc	保存添加数据
	 * @param request
	 * @param response
	 * @throws IOException 
	 * @throws SQLException 
	 * @throws FileNotFoundException 
	 * @throws ClassNotFoundException 
	 */
	private void addPage(HttpServletRequest request, HttpServletResponse response) throws ClassNotFoundException, FileNotFoundException, SQLException, IOException {
		System.out.println("进入ClasssServlet--->addPage()");
		// 获取数据
		String classs_name = request.getParameter("classs_name");
		String classs_id = UUID.randomUUID().toString().substring(9);
		
		// 获取当前时间
		SimpleDateFormat formatter= new SimpleDateFormat("yyyy年MM月dd日   HH:mm:ss");
		// 获取当前时间戳
		Date date = new Date(System.currentTimeMillis());
		String classs_time = formatter.format(date);
		
		// 调用工具类保存数据
		classsService.addPage(classs_id,classs_name,classs_time);
		
		// 刷新页面
		response.sendRedirect(request.getContextPath()+ "/classs.do?method=query");
	}
	/**
	 * @desc	转跳添加界面
	 * @param request
	 * @param response
	 * @throws IOException 
	 * @throws ServletException 
	 */
	private void add(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		System.out.println("进入ClasssServlet--->add()转跳界面");
		request.getRequestDispatcher("manage/classs/add.jsp").forward(request, response);
		System.out.println("跳转成功");
	}

	/**
	 * @desc 获取全部数据方法
	 * @param request
	 * @param response
	 * @throws SQLException
	 * @throws ClassNotFoundException
	 * @throws IOException
	 * @throws ServletException
	 */
	private void query(HttpServletRequest request, HttpServletResponse response)
			throws ClassNotFoundException, SQLException, ServletException, IOException {
		System.out.println("进入了ClasssServlet--->query");
		List<Map<String, Object>> list = classsService.queryAll();
		// 存入
		request.setAttribute("list", list);
		// 转向
		request.getRequestDispatcher("manage/classs/list.jsp").forward(request, response);
	}

}
