package com.turing.manage.classs;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;

public interface IClasssService {

	List<Map<String, Object>> queryAll() throws ClassNotFoundException, SQLException;

	void addPage(String classs_id, String classs_name, String classs_time) throws ClassNotFoundException, FileNotFoundException, SQLException, IOException;

	void delete(String[] strings) throws ClassNotFoundException, FileNotFoundException, SQLException, IOException;

	Map<String, Object> queryOneByUserID(String classs_id) throws ClassNotFoundException, SQLException;

	void editPage(String classs_id, String classs_name) throws ClassNotFoundException, SQLException;

}
