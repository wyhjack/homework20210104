package com.turing.manage.manager;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.net.URL;
import java.net.URLConnection;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileUploadException;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
import org.apache.commons.io.FileUtils;
import org.apache.commons.io.IOUtils;

import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * @desc 登录模块C层
 * @author 86186
 *
 */
public class ManagerServlet extends HttpServlet {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	// 创建M层工具类
	IManagerService managerServlet = new ManagerServiceImpl();

	@Override
	protected void service(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		System.out.println("ManagerServlet--->service()");
		String method = request.getParameter("method");
		try {
			if (method.equals("query")) {
				this.query(request, response);
			} else if (method.equals("upload")) {
				this.upload(request, response);
			} else if (method.equals("download")) {
				this.download(request, response);
			} else if (method.equals("delete")) {
				this.delete(request, response);
			} else if (method.equals("editPage")) {
				this.editPage(request, response);
			} else if (method.equals("edit")) {
				this.edit(request, response);
			} else if (method.equals("queryAjax")) {
				this.queryAjax(request, response);
			} else if (method.equals("lolly")) {
				this.doJson(request, response);
			}
		} catch (ClassNotFoundException e) {
			System.out.println("此类不存在");
		} catch (SQLException e) {
			System.out.println("SQL语句异常");
			e.printStackTrace();
		} catch (FileUploadException e) {
			e.printStackTrace();
			System.out.println("FileUploadException异常");
		}
	}

	/**
	 * @desc 测试Json的方法
	 * @param request
	 * @param response
	 * @throws SQLException
	 * @throws ClassNotFoundException
	 * @throws IOException
	 * @throws JsonMappingException
	 * @throws JsonGenerationException
	 */
	private void doJson(HttpServletRequest request, HttpServletResponse response)
			throws ClassNotFoundException, SQLException, JsonGenerationException, JsonMappingException, IOException {
		System.out.println("进入doJson方法");
		// 获取全部管理员数据
		List<Map<String, Object>> list = managerServlet.queryAll();
		// 把list转为Json字符串
		String strJson = this.jsonOut(list);
		System.out.println(strJson);
		// 创建流把数据返回
		PrintWriter out = response.getWriter();
		out.write(strJson);
		out.flush();
		out.close();
	}

	/**
	 * 将对象转换为字符串
	 * 
	 * @param ob
	 * @return
	 * @throws IOException
	 * @throws JsonMappingException
	 * @throws JsonGenerationException
	 */

	private String jsonOut(Object ob) throws JsonGenerationException, JsonMappingException, IOException {
		//初始化JackSon包中的解析json的核心类
		ObjectMapper om = new ObjectMapper();
		String json = om.writeValueAsString(ob);
		return json;

	}

	/**
	 * @desc 进行访问数据,查看是否重复用户名
	 * @param request
	 * @param response
	 * @throws SQLException
	 * @throws ClassNotFoundException
	 * @throws IOException
	 */
	private void queryAjax(HttpServletRequest request, HttpServletResponse response)
			throws ClassNotFoundException, SQLException, IOException {
		System.out.println("进入到Ajax的判断数据是否存在方法");
		// 设置类型
		response.setContentType("text/html;charset=utf-8");
		String manager_name = request.getParameter("manager_name");
		String data = "";
		// 查询数据库,查看是否有无该数据用户名
		int count = managerServlet.queryManagerByName(manager_name);
		// 获取一个向前端输入的流
		PrintWriter out = response.getWriter();
		System.out.println("count==" + count);
		if (count > 0) {
			data = "no";
		} else {
			data = "yes";
		}
		// 写入刷新关闭
		out.write(data);
		out.flush();
		out.close();
	}

	/**
	 * @desc 把获取的数据储存
	 * @param request
	 * @param response
	 * @throws SQLException
	 * @throws ClassNotFoundException
	 * @throws IOException
	 * @throws FileUploadException
	 */
	private void edit(HttpServletRequest request, HttpServletResponse response)
			throws ClassNotFoundException, SQLException, IOException, FileUploadException {
		System.out.println("进入数据储存方法");
		String manager_id = request.getParameter("manager_id");

		System.out.println("数据信息LLLLL");
		System.out.println(manager_id);
		// 设置相应编码集
		response.setContentType("text/html;charset=UTF-8");
		// 定义变量
		// 文件保存时候的名字
		String fileSaveName = null;
		// 解析的结果
		List<FileItem> formItemList = null;

		// 设置图片保存路径,本次使用本电脑系统作为服务器
		String path = this.getServletContext().getRealPath("/") + "WEB-INF/image";
		System.out.println("图片的存储路径为:" + path);

		// 判断是否存在
		File file = new File(path);
		if (!file.exists()) {
			file.mkdir();// 如果不存在就创建
		}

		// 创建工厂类
		DiskFileItemFactory factory = new DiskFileItemFactory();

		// 创建具体功能类
		ServletFileUpload upload = new ServletFileUpload(factory);
		// 处理中文
		upload.setHeaderEncoding("utf-8");
		// 数据传进去,获取具体解析到的结果
		formItemList = upload.parseRequest(request);
		// 判断是否包含数据
		System.out.println(formItemList.size());
		if (formItemList != null && formItemList.size() > 0) {
			for (FileItem fileItem : formItemList) {
				// 判断是否是文件类型
				if (!fileItem.isFormField()) {
					String fileName = fileItem.getName(); // 获取上传文件的名字
					// 获取后缀
					String prifix = fileName.substring(fileName.lastIndexOf(".") + 1);
					System.out.println("后缀为:" + prifix);
					// 创建ID绑定session,区分用户
					String id = UUID.randomUUID().toString();
					fileSaveName = id + "." + prifix;
					if (prifix.length() == 0) {
						fileSaveName = "(NULL)";
					}
					System.out.println("文件保存的名字为:" + fileSaveName);
					// 使用commons-io把图片复制进本地
					FileUtils.copyInputStreamToFile(fileItem.getInputStream(), new File(path + "/" + fileSaveName));
				}
			}

		}
		String manager_name = formItemList.get(1).getString("utf-8");
		System.out.println("manager_name" + manager_name);
		String manager_pass = formItemList.get(2).getString("utf-8");
		System.out.println("manager_pass" + manager_pass);

		String manager_imgpath = request.getParameter("manager_imgpath");
		System.out.println("manager_imgpath" + manager_imgpath);
		System.out.println("文件储存" + fileSaveName);
		System.out.println(fileSaveName.equals("(NULL)"));
		if (fileSaveName.equals("(NULL)")) {
			managerServlet.edit(manager_id, manager_name, manager_pass, manager_imgpath);
		} else {
			// 调用工具类储存
			managerServlet.edit(manager_id, manager_name, manager_pass, fileSaveName);
		}

		// 转跳
		response.sendRedirect(request.getContextPath() + "/manage/manager.do?method=query");
	}

	/**
	 * @desc 转跳更新数据页面
	 * @param request
	 * @param response
	 * @throws SQLException
	 * @throws ClassNotFoundException
	 * @throws IOException
	 * @throws ServletException
	 */
	private void editPage(HttpServletRequest request, HttpServletResponse response)
			throws ClassNotFoundException, SQLException, ServletException, IOException {
		System.out.println("进入至修改数据页面");
		// 接收对应的数据的userID
		String manager_id = request.getParameter("manager_id");
		System.out.println("manager_id:" + manager_id);
		// 获取对应的数据
		Map<String, Object> map = managerServlet.queryOneByUserID(manager_id);

		// 存入到request中
		request.setAttribute("map", map);
		System.out.println(map);
		// 转向至添加数据界面
		request.getRequestDispatcher("/manage/manager/edit.jsp").forward(request, response);
	}

	/**
	 * @desc 删除数据方法
	 * @param request
	 * @param response
	 * @throws SQLException
	 * @throws ClassNotFoundException
	 * @throws IOException
	 */
	private void delete(HttpServletRequest request, HttpServletResponse response)
			throws ClassNotFoundException, SQLException, IOException {
		System.out.println("正在进行删除数据");
		// 接收主键值
		String manager_id = request.getParameter("manager_id");
		// 调用工具类进行删除
		managerServlet.delete(manager_id);
		// 重定向==刷新
		response.sendRedirect(request.getContextPath() + "/manage/manager.do?method=query");
	}

	/**
	 * @desc 下载图片
	 * @param request
	 * @param response
	 * @throws IOException
	 */
	private void download(HttpServletRequest request, HttpServletResponse response) throws IOException {
		try {
			// 接值：
			String manager_imgpath = request.getParameter("manager_imgpath");
			// 获取地址路径
			String path = this.getServletContext().getRealPath("/") + "WEB-INF/image/";
			System.out.println(path + manager_imgpath);
			File file = new File(path + manager_imgpath);// 将服务器上的图片路径转换为文件
			FileInputStream fileInputStream = new FileInputStream(file);// 将上步的文件转变为流
			System.out.println("fileInputStream----->" + fileInputStream);
			response.setContentType("image/jpg"); // 设置返回的文件类型
			response.setHeader("Access-Control-Allow-Origin", "*");// 设置该图片允许跨域访问
			IOUtils.copy(fileInputStream, response.getOutputStream());// 利用commons-io.jar包中的方法实现根据文件输出流转换为图片

		} catch (FileNotFoundException e) { // 如若没有上传头像则使用默认头像
			// // 获取地址路径
			// String path = this.getServletContext().getRealPath("/") +
			// "WEB-INF/image/默认头像.jpg";
			// File file = new File(path);// 将服务器上的图片路径转换为文件
			// FileInputStream fileInputStream = new FileInputStream(file);//
			// 将上步的文件转变为流
			// System.out.println("fileInputStream----->" + fileInputStream);
			// response.setContentType("image/jpg"); // 设置返回的文件类型
			// response.setHeader("Access-Control-Allow-Origin", "*");//
			// 设置该图片允许跨域访问
			// IOUtils.copy(fileInputStream, response.getOutputStream());//
			// 利用commons-io.jar包中的方法实现根据文件输出流转换为图片
			URLImag(request, response);
		} finally {
			if (request.getParameter("manager_imgpath").equals("(NULL)")) {
				URLImag(request, response);
			}
		}

	}

	// 外链的默认图片
	public void URLImag(HttpServletRequest request, HttpServletResponse response) throws IOException {
		// 外链地址
		String imgURL = "http://r.photo.store.qq.com/psc?/V13gIr0B03EFQU/TmEUgtj9EK6.7V8ajmQrEMii1zBM6bVqBm*HSJNOPLEGWm6nJMxNPvLeMACBmbnp7rAWZ2aGZeg5*smtXYHS9iIjgsuqNwEIIRfy35s2rHQ!/r";
		// 初始化URL类
		URL url = new URL(imgURL);
		// 把URL转为流
		URLConnection connection = url.openConnection();
		InputStream inputStream = connection.getInputStream();

		response.setContentType("image/jpg"); // 设置返回的文件类型
		response.setHeader("Access-Control-Allow-Origin", "*");// 设置该图片允许跨域访问
		IOUtils.copy(inputStream, response.getOutputStream());// 利用commons-io.jar包中的方法实现根据文件输出流转换为图片

	}

	/**
	 * @desc 上传图片
	 * @param request
	 * @param response
	 * @throws FileUploadException
	 * @throws IOException
	 * @throws SQLException
	 * @throws ClassNotFoundException
	 * @throws ServletException
	 */
	@SuppressWarnings({ "unused", "unchecked" })
	private void upload(HttpServletRequest request, HttpServletResponse response)
			throws FileUploadException, IOException, ClassNotFoundException, SQLException, ServletException {
		// 设置相应编码集
		response.setContentType("text/html;charset=UTF-8");
		// 定义变量
		// 文件保存时候的名字
		String fileSaveName = null;
		// 解析的结果
		List<FileItem> formItemList = null;

		// 设置图片保存路径,本次使用本电脑系统作为服务器
		String path = this.getServletContext().getRealPath("/") + "WEB-INF/image";
		System.out.println("图片的存储路径为:" + path);

		// 判断是否存在
		File file = new File(path);
		if (!file.exists()) {
			file.mkdir();// 如果不存在就创建
		}

		// 创建工厂类
		DiskFileItemFactory factory = new DiskFileItemFactory();

		// 创建具体功能类
		ServletFileUpload upload = new ServletFileUpload(factory);
		// 处理中文
		upload.setHeaderEncoding("utf-8");
		// 数据传进去,获取具体解析到的结果
		formItemList = upload.parseRequest(request);
		// 判断是否包含数据
		System.out.println(formItemList.size());
		if (formItemList != null && formItemList.size() > 0) {
			for (FileItem fileItem : formItemList) {
				// 判断是否是文件类型
				if (!fileItem.isFormField()) {
					String fileName = fileItem.getName(); // 获取上传文件的名字
					// 获取后缀
					String prifix = fileName.substring(fileName.lastIndexOf(".") + 1);
					System.out.println("后缀为:" + prifix);
					// 创建ID绑定session,区分用户
					String id = UUID.randomUUID().toString();
					fileSaveName = id + "." + prifix;
					if (prifix.length() == 0) {
						fileSaveName = "(NULL)";
					}
					System.out.println("文件保存的名字为:" + fileSaveName);
					// 使用commons-io把图片复制进本地
					FileUtils.copyInputStreamToFile(fileItem.getInputStream(), new File(path + "/" + fileSaveName));
				}
			}

		}
		// 调用M层保存数据的一致性
		String virtualPath = fileSaveName;
		String manager_name = formItemList.get(0).getString("utf-8");
		System.out.println("manager_name" + manager_name);
		String manager_pass = formItemList.get(1).getString("utf-8");
		System.out.println("manager_pass" + manager_pass);
		// 添加数据库
		managerServlet.save(manager_name, manager_pass, virtualPath);
		// 重定向
		response.sendRedirect(request.getContextPath() + "/manage/manager.do?method=query");
	}

	/**
	 * @desc 获取全部管理员数据
	 * @param request
	 * @param response
	 * @throws SQLException
	 * @throws ClassNotFoundException
	 * @throws IOException
	 * @throws ServletException
	 */
	private void query(HttpServletRequest request, HttpServletResponse response)
			throws ClassNotFoundException, SQLException, ServletException, IOException {
		System.out.println("ManagerServlet--->query()");
		// 调用M层方法获取数据
		List<Map<String, Object>> list = managerServlet.queryAll();
		// 存入数据
		request.setAttribute("list", list);
		// 转向
		request.getRequestDispatcher("/manage/manager/list.jsp").forward(request, response);
		// 暂时无法使用重定向
		// response.sendRedirect(request.getContextPath() +
		// "/manage/manager.do?method/query");
	}

}
