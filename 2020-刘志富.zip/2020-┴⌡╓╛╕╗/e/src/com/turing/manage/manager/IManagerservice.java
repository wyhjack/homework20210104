package com.turing.manage.manager;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;

public interface IManagerService {

	public List<Map<String, Object>> queryAll() throws ClassNotFoundException, SQLException;

	public void save(String manager_name, String manager_pass, String virtualPath) throws ClassNotFoundException, FileNotFoundException, SQLException, IOException;

	public void delete(String manager_id) throws ClassNotFoundException, SQLException;

	public Map<String, Object> queryOneByUserID(String manager_id) throws ClassNotFoundException, SQLException;

	public void edit(String manager_id,String manager_name, String manager_pass, String manager_imgpath) throws ClassNotFoundException, SQLException;

	public int queryManagerByName(String manager_name) throws ClassNotFoundException, SQLException;

}
