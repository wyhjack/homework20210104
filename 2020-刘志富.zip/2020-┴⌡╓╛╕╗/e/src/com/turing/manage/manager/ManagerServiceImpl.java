package com.turing.manage.manager;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.SQLException;
import java.sql.Types;
import java.util.List;
import java.util.Map;

import com.turing.dao.Dao;
import com.turing.dao.DaoImpl;

public class ManagerServiceImpl implements IManagerService{
	// 创建dao工具类
	Dao dao = new DaoImpl();
	@Override
	public List<Map<String, Object>> queryAll() throws ClassNotFoundException, SQLException {
		//使用dao工具类获取manager全部数据
		return dao.executeQueryForList("select * from manager;");
	}
	
	@Override
	public void save(String manager_name, String manager_pass, String virtualPath) throws ClassNotFoundException, FileNotFoundException, SQLException, IOException {
		dao.executeUpdate(" insert into manager values (0,?,?,?)",new int[]{Types.VARCHAR,Types.VARCHAR,Types.VARCHAR},new Object[]{manager_name,manager_pass,virtualPath});
	}

	@Override
	public void delete(String manager_id) throws ClassNotFoundException, SQLException {
		dao.executeUpdate("  delete from manager where manager_id='" + manager_id + "'  ");
	}

	@Override
	public Map<String, Object> queryOneByUserID(String manager_id) throws ClassNotFoundException, SQLException {
		return dao.executeQueryForMap("select * from manager where manager_id = '"+ manager_id+"';");
	}

	@Override
	public void edit(String manager_id,String manager_name, String manager_pass, String manager_imgpath) throws ClassNotFoundException, SQLException {
		System.out.println(manager_id);
		System.out.println(manager_name);
		System.out.println(manager_pass);
		System.out.println(manager_imgpath);
		
		dao.executeUpdate(
				"update manager set manager_name='" + manager_name + "',manager_pass='" + manager_pass+ "',manager_imgpath='" + manager_imgpath + "' where manager_id='" + manager_id + "'");
		
	}

	@Override
	public int queryManagerByName(String manager_name) throws ClassNotFoundException, SQLException {
		
		return dao.executeQueryForInt("select count(*) from manager where manager_name= ?" , new int[]{Types.VARCHAR}, new Object[]{manager_name});
	}
	
}
 