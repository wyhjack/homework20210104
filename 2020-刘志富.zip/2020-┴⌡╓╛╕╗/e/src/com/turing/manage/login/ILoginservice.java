package com.turing.manage.login;

import java.sql.SQLException;
import java.util.Map;

/**
 * @desc 登录模块的M层的接口
 * @author 86186
 */
public interface ILoginService {

	Map<String, Object> queryManagerByNameAndPass(String name, String pass) throws ClassNotFoundException, SQLException;
	
}
