package com.turing.manage.login;

import java.io.IOException;
import java.sql.SQLException;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * @desc 登录模块的C层
 * @author 86186
 */
public class LoginServlet extends HttpServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	ILoginService loginService = new LoginServiceImpl();
	HttpSession session;
	@Override
	protected void service(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		System.out.println("LoginServlet---->service()");
		
		String method = request.getParameter("method");

		try {
			if (method.equals("login")) {
				this.login(request, response);
			} else if (method.equals("logout")) {
				this.logout(request,response);
			}
		} catch (ClassNotFoundException e) {
			System.out.println("找不到此类");
		} catch (SQLException e) {
			System.out.println("SQL语句异常");
		}
	}
	/**
	 * @desc	2.退出登录
	 * @param request
	 * @param response
	 * @throws IOException 
	 * @throws ServletException 
	 */
	private void logout(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("LoginServlet---->logout()");

		// 销毁session
		session.invalidate();
		// 转向至登录页面
		request.getRequestDispatcher("/manage/login.jsp").forward(request, response);
	}

	/**
	 * @desc 1.登录
	 * @param request
	 * @param response
	 * @throws SQLException
	 * @throws ClassNotFoundException
	 * @throws IOException 
	 * @throws ServletException 
	 */
	private void login(HttpServletRequest request, HttpServletResponse response)
			throws ClassNotFoundException, SQLException, ServletException, IOException {
		System.out.println("loginServlet--->login()");
		// 1.接受用户传入的值
		String name = request.getParameter("name");
		String pass = request.getParameter("pass");
		// 验证数据
		System.out.println("name" + name);
		System.out.println("pass" + pass);

		// 2. 调用M层用户名和密码实现验证

		Map<String, Object> map = loginService.queryManagerByNameAndPass(name, pass);
	
		// 3.判断是否登录成功
		if (map == null) {
			// 4.登录失败跳转页面
			System.out.println("登陆失败,用户名或密码错误");
			request.setAttribute("error", "请输入正确的用户名和密码");
			request.getRequestDispatcher("/manage/error.jsp").forward(request, response);

		} else {
			System.out.println("登录成功");
			// 存入session
			session = request.getSession();
			session.setAttribute("user", map);// 将查询获取到的该条用户信息存入到session中
			// sessionID
			String sessionId = session.getId();
			//response.getWriter().print("session创建成功,session的id是:" + sessionId);
			System.out.println("session创建成功,session的id是:" + sessionId);
			// 4.重定向至管理页面
			response.sendRedirect(request.getContextPath()+"/manage/manager.do?method=query");
//			request.getRequestDispatcher("/manage/manager/list.jsp").forward(request, response);
		}
	}

}
