package com.turing.bc;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class DateUtils {
	public static void main(String[] args) throws ParseException {
		String dateStr = "2020-12-13";
		Date now = new Date();
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
		String toStr = format.format(now);
		System.out.println(DateUtils.differentDaysByMillisecond(toStr, dateStr));
		int result = DateUtils.differentDaysByMillisecond(toStr, dateStr);
		if ((result >= 0) && (result <= 5)) {
			System.out.println("提醒用户实现发送生日祝福");
		} else {
			System.out.println("不发送");
		}
	}

	/**
	 * @desc 判断还有多久过生日
	 * @param dateStr 现在的时间
	 * @param dateStr2 生日
	 * @return
	 * @throws ParseException
	 */
	public static int differentDaysByMillisecond(String dateStr, String dateStr2) throws ParseException {
		// 1.初始化格式化工具类
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
		// 2.将字符串类型的日期转变为日期类型
		Date fDate = format.parse(dateStr);
		Date oDate = format.parse(dateStr2);
		// 3.初始化日历工具类
		Calendar aCalendar = Calendar.getInstance();
		// 4.根据日历工具类对象将上面获取到的两个日期转变为天
		aCalendar.setTime(fDate);
		int day1 = aCalendar.get(Calendar.DAY_OF_YEAR);

		// 5.重复第4步
		aCalendar.setTime(oDate);
		int day2 = aCalendar.get(Calendar.DAY_OF_YEAR);
		return day2 - day1;
	}
}
