package com.turing.filter;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
* @desc	      
* @auther 温润如玉
* @time   2020年12月3日上午10:29:45
**/
public class SessionFilter implements Filter {

	@Override
	public void destroy() {
		System.out.println("过滤器销毁");
		
	}

	@Override
	public void doFilter(ServletRequest arg0, ServletResponse arg1, FilterChain arg2)
			throws IOException, ServletException {
		System.out.println("过滤器开始");
		HttpServletRequest request = (HttpServletRequest) arg0;
		HttpServletResponse response = (HttpServletResponse) arg1;

		//2.设置特权放行页面
		String path = request.getServletPath();
		
		if (("/manage/login.jsp".equals(path))||("/manage/login.do".equals(path))) {
			System.out.println("当前是特权页面，放行 ");
			arg2.doFilter(request, response);
			return;
		}
		
		//3.session的过滤
		HttpSession session = request.getSession();
		if (session.getAttribute("user")==null) {
			System.out.println("session为空，您还没有登录");
			String errorMsg="您还没有登录，不能访问本页面！<br/>请登陆后再试";
			request.setAttribute("error", errorMsg);
			request.getRequestDispatcher("/manage/error.jsp").forward(request, response);
			return;
		}else {
			System.out.println("验证通过");
			arg2.doFilter(request, response);
			return;
		}
		
	}

	@Override
	public void init(FilterConfig arg0) throws ServletException {
		System.out.println("过滤器开始初始化了");
		
	}

}
